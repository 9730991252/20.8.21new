from django import forms
from shop.models import Product

class Product_Upadate_Form(forms.ModelForm):
    class Meta:
        model=Product
        fields = ['product_name','price','sub_category','desc','image']